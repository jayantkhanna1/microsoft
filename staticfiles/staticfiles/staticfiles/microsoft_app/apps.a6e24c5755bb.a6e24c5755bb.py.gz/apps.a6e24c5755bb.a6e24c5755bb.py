from django.apps import AppConfig


class MicrosoftAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'microsoft_app'
